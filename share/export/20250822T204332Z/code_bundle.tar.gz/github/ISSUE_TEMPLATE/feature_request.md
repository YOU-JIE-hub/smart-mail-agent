---
name: 🚀 Feature Request
about: 建議新增或改進功能
labels: enhancement
---

**動機 / 背景**
為什麼需要這個功能？

**方案草稿**
你希望怎麼實現？

**驗收標準**
- [ ] 1
- [ ] 2
