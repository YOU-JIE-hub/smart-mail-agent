# 安全性政策
請以 GitHub Security Advisories 或私訊回報漏洞；收到後將評估、修補並發版。
