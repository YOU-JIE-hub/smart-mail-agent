# legacy_lowcov
歷史相容用的舊實作快照；不參與 CI 測試與發佈。
