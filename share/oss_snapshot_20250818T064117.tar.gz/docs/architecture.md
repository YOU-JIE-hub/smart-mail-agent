# 技術架構（摘要）
- spam：規則 + ML/LLM 多層過濾
- features：報價、apply_diff、觀測
- routing：動作路由主流程
- ingestion：資料初始化與郵件處理
- utils：PDF、記錄、DB、郵件等共用元件
