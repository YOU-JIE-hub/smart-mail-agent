# Legacy package shim: `import spam` -> `smart_mail_agent.spam`
from smart_mail_agent.spam import *  # noqa: F401,F403
