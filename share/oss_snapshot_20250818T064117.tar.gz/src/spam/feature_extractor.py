from smart_mail_agent.spam.feature_extractor import *  # noqa: F401,F403
