from smart_mail_agent.spam.rules import *  # noqa: F401,F403
