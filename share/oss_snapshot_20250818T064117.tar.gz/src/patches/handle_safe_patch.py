from smart_mail_agent.patches.handle_safe_patch import *  # noqa: F401,F403
