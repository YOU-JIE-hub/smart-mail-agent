# legacy compatibility package for tests
