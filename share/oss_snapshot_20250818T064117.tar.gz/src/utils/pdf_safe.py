from smart_mail_agent.utils.pdf_safe import *  # noqa: F401,F403
