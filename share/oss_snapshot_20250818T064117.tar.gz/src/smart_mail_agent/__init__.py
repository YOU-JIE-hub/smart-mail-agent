#!/usr/bin/env python3
from __future__ import annotations

# 檔案位置: src/smart_mail_agent/__init__.py
from .__version__ import __version__

__all__ = ["__version__"]
