#!/usr/bin/env python3
from __future__ import annotations

# 檔案位置: src/smart_mail_agent/__version__.py
__all__ = ["__version__"]
__version__ = "0.4.6"
