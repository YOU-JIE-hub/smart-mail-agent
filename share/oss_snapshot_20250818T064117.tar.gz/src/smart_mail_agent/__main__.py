"""Entry point for `python -m smart_mail_agent` -> CLI."""

from smart_mail_agent.cli.sma import main

if __name__ == "__main__":
    raise SystemExit(main())
