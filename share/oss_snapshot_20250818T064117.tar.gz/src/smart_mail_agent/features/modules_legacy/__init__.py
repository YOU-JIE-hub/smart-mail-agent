from __future__ import annotations

from smart_mail_agent.features import *  # legacy shim  # noqa: F403,F401
