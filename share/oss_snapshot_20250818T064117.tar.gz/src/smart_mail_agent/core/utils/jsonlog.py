"""Compat shim: keep old import path working."""

from smart_mail_agent.utils.jsonlog import log_event

__all__ = ["log_event"]
