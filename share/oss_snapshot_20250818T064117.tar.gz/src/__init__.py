# Legacy shim: allow tests to `import smart_mail_agent.*`.
