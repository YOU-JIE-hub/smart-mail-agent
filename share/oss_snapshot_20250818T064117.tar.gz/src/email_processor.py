# Legacy shim for tests importing `email_processor`
from smart_mail_agent.ingestion.email_processor import *  # noqa: F401,F403
