#!/usr/bin/env python3
# 檔案位置：spam/__init__.py
# 模組用途：相容層封裝
