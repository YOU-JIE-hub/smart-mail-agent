"""Compatibility proxy to canonical implementation."""

from utils.jsonlog import log_event  # noqa: F401
